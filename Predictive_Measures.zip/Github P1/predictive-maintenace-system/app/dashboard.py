"""
🎛️ PREDICTIVE MAINTENANCE DASHBOARD - PRODUCTION VERSION
Uses actual trained ML models for real predictions
Run: streamlit run app/dashboard.py
"""

import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import joblib
import warnings
warnings.filterwarnings('ignore')

# Page configuration
st.set_page_config(
    page_title="Predictive Maintenance System",
    page_icon="🔧",
    layout="wide",
    initial_sidebar_state="expanded",
    # This might help with theme issues
    menu_items={
        'Get Help': None,
        'Report a bug': None,
        'About': "Predictive Maintenance Dashboard v1.0"
    }
)

# Force light theme
st.markdown("""
    <script>
        // Force light theme
        const htmlElement = document.querySelector('html');
        htmlElement.setAttribute('data-theme', 'light');
    </script>
""", unsafe_allow_html=True)

# Load trained models and data
@st.cache_resource
def load_models_and_data():
    """Load trained ML models and sample data"""
    try:
        # Load models
        model = joblib.load(r'C:\Users\pavan\Documents\Github P1\predictive-maintenace-system\models\best_predictive_maintenance_model.pkl')
        scaler = joblib.load(r'C:\Users\pavan\Documents\Github P1\predictive-maintenace-system\models\feature_scaler.pkl')
        feature_names = joblib.load(r'C:\Users\pavan\Documents\Github P1\predictive-maintenace-system\models\feature_names.pkl')
        
        # Load sample data for visualization
        df = pd.read_csv(r'C:\Users\pavan\Documents\Github P1\predictive-maintenace-system\data\processed\predictive_maintenance_engineered.csv')
        
        return model, scaler, feature_names, df
    
    except FileNotFoundError as e:
        st.error(f"Model file not found: {e}")
        st.info("Please run the modeling notebook first to train and save models.")
        return None, None, None, None

# Load everything
model, scaler, feature_names, df = load_models_and_data()

def predict_failure_probability(sensor_data):
    """Predict failure probability using trained model"""
    if model is None or scaler is None or feature_names is None:
        return 50.0  # Default if models not loaded
    
    try:
        # Create input dataframe with correct feature order
        input_df = pd.DataFrame([sensor_data])
        
        # Ensure all required features are present
        missing_features = set(feature_names) - set(input_df.columns)
        for feature in missing_features:
            input_df[feature] = 0  # Default value for missing features
        
        # Reorder columns to match training
        input_df = input_df[feature_names]
        
        # Scale features
        input_scaled = scaler.transform(input_df)
        
        # Predict probability of failure (class 1)
        if hasattr(model, 'predict_proba'):
            proba = model.predict_proba(input_scaled)[0][1]
        else:
            # If model doesn't have predict_proba, use decision function
            prediction = model.predict(input_scaled)[0]
            proba = prediction if prediction in [0, 1] else 0.5
        
        return proba * 100  # Convert to percentage
    
    except Exception as e:
        st.error(f"Prediction error: {e}")
        return 50.0

def calculate_health_metrics(row):
    """Calculate equipment health metrics from sensor data"""
    metrics = {}
    
    # Temperature stability
    metrics['temp_stability'] = 100 - abs(row.get('temp_difference', 10) - 10) * 5
    
    # Power efficiency
    metrics['power_efficiency'] = 100 - abs(row.get('power_estimate', 60) - 60) * 0.5
    
    # Wear level (0-100, 100 = new)
    if 'Tool wear [min]' in row:
        metrics['wear_health'] = max(0, 100 - (row['Tool wear [min]'] / 250) * 100)
    elif 'tool_wear_rate' in row:
        metrics['wear_health'] = 100 - row['tool_wear_rate'] * 100
    else:
        metrics['wear_health'] = 75
    
    # Overall health score (weighted average)
    metrics['health_score'] = (
        metrics['temp_stability'] * 0.3 +
        metrics['power_efficiency'] * 0.3 +
        metrics['wear_health'] * 0.4
    )
    
    # Remaining useful life (estimated)
    if 'Tool wear [min]' in row:
        remaining_wear = 250 - row['Tool wear [min]']
        metrics['remaining_life'] = max(0, remaining_wear * 0.8)  # hours
    else:
        metrics['remaining_life'] = 100
    
    return metrics

# Main dashboard
def main():
    st.markdown('<h1 class="main-header">🔧 Predictive Maintenance Dashboard</h1>', unsafe_allow_html=True)
    st.markdown("Real-time monitoring using trained ML models")
    
    # Sidebar
    with st.sidebar:
        st.title("⚙️ Controls")
        
        # Equipment selection
        st.subheader("Equipment")
        if df is not None and 'Product ID' in df.columns:
            equipment_options = df['Product ID'].unique()[:20]
        else:
            equipment_options = [f"Machine_{i:03d}" for i in range(1, 21)]
        
        selected_equipment = st.selectbox("Select Equipment", equipment_options)
        
        # Alert threshold
        st.subheader("Alert Settings")
        alert_threshold = st.slider(
            "Failure Alert Threshold (%)",
            min_value=50,
            max_value=95,
            value=70,
            step=5
        )
        
        # Real-time simulation
        st.subheader("Sensor Simulation")
        simulate_anomaly = st.checkbox("Simulate Failure Conditions", value=False)
        
        if simulate_anomaly:
            st.warning("⚠️ Anomaly simulation enabled")
        
        if st.button("🔄 Refresh Predictions"):
            st.rerun()
    
    # If models not loaded, show warning
    if model is None:
        st.warning("""
        ⚠️ **Models not loaded!**
        
        Please run the modeling notebook first:
        1. Open `notebooks/03_modeling.ipynb`
        2. Run all cells to train models
        3. Models will be saved to `models/` folder
        
        For now, using simulated predictions.
        """)
    
    # Get current sensor data
    if df is not None and len(df) > 0:
        # Get latest or random sample
        current_data = df.iloc[-1].to_dict() if not simulate_anomaly else df.sample().iloc[0].to_dict()
        
        # Simulate anomaly if requested
        if simulate_anomaly:
            current_data['Torque [Nm]'] = current_data.get('Torque [Nm]', 40) * 1.5
            current_data['Rotational speed [rpm]'] = current_data.get('Rotational speed [rpm]', 1500) * 0.7
            current_data['Tool wear [min]'] = current_data.get('Tool wear [min]', 100) + 100
    else:
        # Default values if no data
        current_data = {
            'Air temperature [K]': 300.0,
            'Process temperature [K]': 310.0,
            'Rotational speed [rpm]': 1500.0,
            'Torque [Nm]': 40.0,
            'Tool wear [min]': 120.0,
            'temp_difference': 10.0,
            'power_estimate': 60.0,
            'tool_wear_rate': 0.48
        }
    
    # Calculate health metrics
    health_metrics = calculate_health_metrics(current_data)
    
    # Predict failure probability
    failure_prob = predict_failure_probability(current_data)
    
    # Top metrics row
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric(
            label="Equipment Health Score",
            value=f"{health_metrics['health_score']:.0f}/100",
            delta="Excellent" if health_metrics['health_score'] > 80 else 
                  "Good" if health_metrics['health_score'] > 60 else "Poor",
            delta_color="normal" if health_metrics['health_score'] > 80 else 
                       "off" if health_metrics['health_score'] > 60 else "inverse"
        )
    
    with col2:
        st.metric(
            label="Failure Probability",
            value=f"{failure_prob:.1f}%",
            delta="High Risk" if failure_prob > alert_threshold else "Normal",
            delta_color="inverse" if failure_prob > alert_threshold else "normal"
        )
    
    with col3:
        st.metric(
            label="Remaining Useful Life",
            value=f"{health_metrics['remaining_life']:.0f} cycles",
            delta=f"-{health_metrics['remaining_life']*0.05:.0f}/day"
        )
    
    with col4:
        st.metric(
            label="Temperature Stability",
            value=f"{health_metrics['temp_stability']:.0f}%",
            delta="Stable" if health_metrics['temp_stability'] > 80 else "Unstable"
        )
    
    # Alert section
    if failure_prob > alert_threshold:
        st.markdown(f"""
        <div class="danger-card">
            <h3>🚨 HIGH RISK ALERT</h3>
            <p>Equipment <strong>{selected_equipment}</strong> has <strong>{failure_prob:.1f}%</strong> failure probability.</p>
            <p><strong>Immediate Action Required:</strong> Schedule maintenance inspection now.</p>
        </div>
        """, unsafe_allow_html=True)
    elif failure_prob > alert_threshold - 20:
        st.markdown(f"""
        <div class="warning-card">
            <h3>⚠️ EARLY WARNING</h3>
            <p>Equipment <strong>{selected_equipment}</strong> shows elevated risk (<strong>{failure_prob:.1f}%</strong>).</p>
            <p><strong>Recommended:</strong> Schedule maintenance within 7 days.</p>
        </div>
        """, unsafe_allow_html=True)
    else:
        st.markdown(f"""
        <div class="metric-card">
            <h3>✅ NORMAL OPERATION</h3>
            <p>Equipment <strong>{selected_equipment}</strong> operating normally.</p>
            <p><strong>Next maintenance:</strong> Due in 30 days</p>
        </div>
        """, unsafe_allow_html=True)
    
    # Charts section
    st.subheader("📊 Sensor Monitoring")
    
    tab1, tab2, tab3 = st.tabs(["Live Sensors", "Health History", "Feature Importance"])
    
    with tab1:
        if df is not None and len(df) > 50:
            # Plot sensor trends
            fig, axes = plt.subplots(2, 2, figsize=(12, 8))
            
            # Temperature
            axes[0, 0].plot(df.index[-50:], df['Air temperature [K]'].tail(50), 'b-', alpha=0.7, label='Air')
            axes[0, 0].plot(df.index[-50:], df['Process temperature [K]'].tail(50), 'r-', alpha=0.7, label='Process')
            axes[0, 0].set_title('Temperature Trends')
            axes[0, 0].set_ylabel('Temperature (K)')
            axes[0, 0].legend()
            axes[0, 0].grid(True, alpha=0.3)
            
            # Rotational Speed
            axes[0, 1].plot(df.index[-50:], df['Rotational speed [rpm]'].tail(50), 'g-', alpha=0.7)
            axes[0, 1].axhline(y=1800, color='r', linestyle='--', alpha=0.5, label='Upper Limit')
            axes[0, 1].set_title('Rotational Speed')
            axes[0, 1].set_ylabel('Speed (rpm)')
            axes[0, 1].legend()
            axes[0, 1].grid(True, alpha=0.3)
            
            # Torque
            axes[1, 0].plot(df.index[-50:], df['Torque [Nm]'].tail(50), 'purple', alpha=0.7)
            axes[1, 0].set_title('Torque')
            axes[1, 0].set_ylabel('Torque (Nm)')
            axes[1, 0].grid(True, alpha=0.3)
            
            # Tool Wear
            axes[1, 1].plot(df.index[-50:], df['Tool wear [min]'].tail(50), 'orange', alpha=0.7)
            axes[1, 1].set_title('Tool Wear')
            axes[1, 1].set_ylabel('Wear (min)')
            axes[1, 1].grid(True, alpha=0.3)
            
            plt.tight_layout()
            st.pyplot(fig)
        else:
            st.info("Not enough data for historical charts. Run feature engineering to generate more data.")
    
    with tab2:
        # Health score history
        if df is not None and len(df) > 10:
            # Calculate health scores for all data
            health_scores = df.head(100).apply(calculate_health_metrics, axis=1, result_type='expand')['health_score']
            
            fig, ax = plt.subplots(figsize=(10, 4))
            ax.plot(health_scores.index, health_scores.values, 'b-', linewidth=2)
            ax.axhline(y=80, color='orange', linestyle='--', label='Warning')
            ax.axhline(y=60, color='red', linestyle='--', label='Critical')
            ax.fill_between(health_scores.index, health_scores.values, 80, 
                           where=(health_scores.values>=80), alpha=0.3, color='green')
            ax.fill_between(health_scores.index, health_scores.values, 80, 
                           where=(health_scores.values<80), alpha=0.3, color='orange')
            ax.fill_between(health_scores.index, health_scores.values, 60, 
                           where=(health_scores.values<60), alpha=0.3, color='red')
            ax.set_title('Equipment Health Score History')
            ax.set_ylabel('Health Score')
            ax.set_xlabel('Sample Index')
            ax.legend()
            ax.grid(True, alpha=0.3)
            st.pyplot(fig)
    
    with tab3:
        # Feature importance
        if model is not None and hasattr(model, 'feature_importances_'):
            if feature_names is not None:
                # Get feature importance
                importance_values = model.feature_importances_
                
                # Create dataframe
                importance_df = pd.DataFrame({
                    'Feature': feature_names,
                    'Importance': importance_values
                }).sort_values('Importance', ascending=False).head(10)
                
                # Plot
                fig, ax = plt.subplots(figsize=(10, 6))
                bars = ax.barh(range(len(importance_df)), importance_df['Importance'])
                ax.set_yticks(range(len(importance_df)))
                ax.set_yticklabels(importance_df['Feature'])
                ax.set_xlabel('Importance')
                ax.set_title('Top 10 Features for Failure Prediction')
                ax.invert_yaxis()
                
                # Color bars by importance
                for i, bar in enumerate(bars):
                    bar.set_color(plt.cm.Reds(i / len(bars)))
                
                st.pyplot(fig)
                
                # Show current values of important features
                st.subheader("Current Feature Values")
                for idx, row in importance_df.head(5).iterrows():
                    feature = row['Feature']
                    value = current_data.get(feature, 'N/A')
                    st.write(f"**{feature}:** {value}")
    
    # Current sensor readings
    with st.expander("🔍 Current Sensor Readings"):
        col1, col2 = st.columns(2)
        
        sensor_readings = {
            'Air Temperature': f"{current_data.get('Air temperature [K]', 'N/A')} K",
            'Process Temperature': f"{current_data.get('Process temperature [K]', 'N/A')} K",
            'Rotational Speed': f"{current_data.get('Rotational speed [rpm]', 'N/A')} rpm",
            'Torque': f"{current_data.get('Torque [Nm]', 'N/A')} Nm",
            'Tool Wear': f"{current_data.get('Tool wear [min]', 'N/A')} min",
            'Temperature Difference': f"{current_data.get('temp_difference', 'N/A')} K",
            'Power Estimate': f"{current_data.get('power_estimate', 'N/A')} kW"
        }
        
        for i, (sensor, value) in enumerate(sensor_readings.items()):
            if i < 4:
                with col1:
                    st.metric(sensor, value)
            else:
                with col2:
                    st.metric(sensor, value)
    
    # Footer
    st.markdown("---")
    st.caption(f"Predictive Maintenance System • Using {'Real ML Model' if model is not None else 'Simulated Predictions'} • Updated: {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')}")

if __name__ == "__main__":
    main()