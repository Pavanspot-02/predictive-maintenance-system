"""
🛠️ Utility Functions for Predictive Maintenance Dashboard
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import joblib

def load_sample_sensor_data(n_samples=100):
    """
    Generate sample sensor data for demonstration
    
    Returns:
        pandas.DataFrame: Sample sensor data
    """
    np.random.seed(42)
    
    # Generate timestamps
    end_time = datetime.now()
    start_time = end_time - timedelta(days=7)
    timestamps = pd.date_range(start=start_time, end=end_time, periods=n_samples)
    
    # Base sensor readings
    base_temp = 300
    base_speed = 1500
    base_torque = 40
    
    data = {
        'timestamp': timestamps,
        'equipment_id': ['EQ-001'] * n_samples,
        'Air temperature [K]': base_temp + np.random.normal(0, 2, n_samples).cumsum() * 0.1,
        'Process temperature [K]': base_temp + 10 + np.random.normal(0, 1.5, n_samples).cumsum() * 0.1,
        'Rotational speed [rpm]': base_speed + np.random.normal(0, 50, n_samples).cumsum(),
        'Torque [Nm]': base_torque + np.random.normal(0, 5, n_samples).cumsum() * 0.1,
        'Tool wear [min]': np.linspace(0, 200, n_samples) + np.random.normal(0, 10, n_samples),
    }
    
    # Add engineered features
    df = pd.DataFrame(data)
    df['temp_difference'] = df['Process temperature [K]'] - df['Air temperature [K]']
    df['power_estimate'] = (df['Rotational speed [rpm]'] * df['Torque [Nm]']) / 1000
    df['tool_wear_rate'] = df['Tool wear [min]'] / df['Tool wear [min]'].max()
    df['speed_torque_ratio'] = df['Rotational speed [rpm]'] / (df['Torque [Nm]'] + 0.1)
    
    # Add some anomalies
    anomaly_indices = np.random.choice(n_samples, size=min(5, n_samples//20), replace=False)
    for idx in anomaly_indices:
        df.loc[idx, 'Rotational speed [rpm]'] *= np.random.choice([0.7, 1.3])
        df.loc[idx, 'Torque [Nm]'] *= np.random.choice([0.7, 1.3])
        df.loc[idx, 'temp_difference'] += np.random.choice([-5, 5])
    
    return df

def create_prediction_input(sensor_readings, feature_names):
    """
    Prepare sensor readings for model prediction
    
    Args:
        sensor_readings (dict): Dictionary of sensor values
        feature_names (list): List of expected feature names
    
    Returns:
        pandas.DataFrame: Prepared input for model
    """
    # Create DataFrame from sensor readings
    input_df = pd.DataFrame([sensor_readings])
    
    # Ensure all required features are present
    for feature in feature_names:
        if feature not in input_df.columns:
            # Provide default values for missing features
            if 'temp' in feature.lower():
                input_df[feature] = 10.0
            elif 'wear' in feature.lower():
                input_df[feature] = 0.5
            elif 'power' in feature.lower():
                input_df[feature] = 60.0
            elif 'speed' in feature.lower() or 'rpm' in feature.lower():
                input_df[feature] = 1500.0
            elif 'torque' in feature.lower():
                input_df[feature] = 40.0
            else:
                input_df[feature] = 0.0
    
    # Reorder columns to match training order
    input_df = input_df[feature_names]
    
    return input_df

def calculate_maintenance_schedule(health_score, failure_prob, last_maintenance):
    """
    Calculate maintenance schedule based on equipment health
    
    Args:
        health_score (float): Equipment health score (0-100)
        failure_prob (float): Failure probability (0-100%)
        last_maintenance (datetime): Last maintenance date
    
    Returns:
        dict: Maintenance schedule information
    """
    now = datetime.now()
    days_since_maintenance = (now - last_maintenance).days if last_maintenance else 30
    
    # Determine maintenance urgency
    if failure_prob > 70 or health_score < 60:
        urgency = "CRITICAL"
        recommended_action = "Immediate maintenance required"
        due_date = now
        color = "red"
    elif failure_prob > 50 or health_score < 70:
        urgency = "HIGH"
        recommended_action = "Schedule within 3 days"
        due_date = now + timedelta(days=3)
        color = "orange"
    elif failure_prob > 30 or health_score < 80 or days_since_maintenance > 60:
        urgency = "MEDIUM"
        recommended_action = "Schedule within 14 days"
        due_date = now + timedelta(days=14)
        color = "yellow"
    else:
        urgency = "LOW"
        recommended_action = "Routine schedule"
        due_date = now + timedelta(days=30)
        color = "green"
    
    return {
        'urgency': urgency,
        'recommended_action': recommended_action,
        'due_date': due_date,
        'color': color,
        'days_since_last': days_since_maintenance
    }

def calculate_roi(downtime_cost_per_hour, maintenance_cost, 
                  failure_prevention_rate, avg_downtime_hours):
    """
    Calculate ROI of predictive maintenance system
    
    Args:
        downtime_cost_per_hour (float): Cost per hour of downtime
        maintenance_cost (float): Cost of preventive maintenance
        failure_prevention_rate (float): % of failures prevented (0-1)
        avg_downtime_hours (float): Average downtime hours per failure
    
    Returns:
        dict: ROI calculation results
    """
    # Assumptions
    avg_failures_per_year = 12
    emergency_repair_multiplier = 3.0
    
    # Without predictive maintenance
    emergency_cost = maintenance_cost * emergency_repair_multiplier
    yearly_cost_without = avg_failures_per_year * (emergency_cost + (downtime_cost_per_hour * avg_downtime_hours))
    
    # With predictive maintenance
    prevented_failures = avg_failures_per_year * failure_prevention_rate
    remaining_failures = avg_failures_per_year - prevented_failures
    
    preventive_maintenance_cost = avg_failures_per_year * maintenance_cost
    emergency_repair_cost = remaining_failures * emergency_cost
    downtime_cost = remaining_failures * (downtime_cost_per_hour * avg_downtime_hours)
    
    yearly_cost_with = preventive_maintenance_cost + emergency_repair_cost + downtime_cost
    
    # Calculate savings and ROI
    yearly_savings = yearly_cost_without - yearly_cost_with
    roi_percentage = (yearly_savings / preventive_maintenance_cost) * 100 if preventive_maintenance_cost > 0 else 0
    
    return {
        'yearly_cost_without': yearly_cost_without,
        'yearly_cost_with': yearly_cost_with,
        'yearly_savings': yearly_savings,
        'roi_percentage': roi_percentage,
        'prevented_failures': prevented_failures,
        'system_cost': preventive_maintenance_cost * 0.5  # Assuming system costs half of maintenance
    }

def save_prediction_log(equipment_id, sensor_data, prediction, timestamp=None):
    """
    Save prediction results to log file
    
    Args:
        equipment_id (str): Equipment identifier
        sensor_data (dict): Sensor readings used for prediction
        prediction (dict): Prediction results
        timestamp (datetime, optional): Prediction timestamp
    
    Returns:
        bool: True if saved successfully
    """
    if timestamp is None:
        timestamp = datetime.now()
    
    log_entry = {
        'timestamp': timestamp,
        'equipment_id': equipment_id,
        'failure_probability': prediction.get('failure_probability', 0),
        'health_score': prediction.get('health_score', 0),
        'recommendation': prediction.get('recommendation', 'Unknown'),
        'sensor_data': str(sensor_data)
    }
    
    try:
        # Convert to DataFrame
        log_df = pd.DataFrame([log_entry])
        
        # Append to log file
        log_file = 'data/logs/predictions_log.csv'
        log_df.to_csv(log_file, mode='a', header=not pd.io.common.file_exists(log_file), index=False)
        return True
    except Exception as e:
        print(f"Error saving log: {e}")
        return False

def validate_sensor_data(sensor_data, expected_ranges):
    """
    Validate sensor readings against expected ranges
    
    Args:
        sensor_data (dict): Sensor readings
        expected_ranges (dict): Dictionary of expected min/max for each sensor
    
    Returns:
        dict: Validation results with warnings for out-of-range sensors
    """
    warnings = []
    
    for sensor, value in sensor_data.items():
        if sensor in expected_ranges:
            min_val, max_val = expected_ranges[sensor]
            if value < min_val or value > max_val:
                warnings.append(f"{sensor}: {value} (expected {min_val}-{max_val})")
    
    return {
        'is_valid': len(warnings) == 0,
        'warnings': warnings,
        'valid_sensors': len(sensor_data) - len(warnings),
        'total_sensors': len(sensor_data)
    }