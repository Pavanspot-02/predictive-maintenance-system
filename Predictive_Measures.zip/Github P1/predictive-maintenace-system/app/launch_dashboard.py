import subprocess
import time
import webbrowser

print("🚀 Launching Predictive Maintenance Dashboard...")

# Install if needed
try:
    import streamlit
except:
    print("Installing Streamlit...")
    subprocess.run(["pip", "install", "streamlit", "pandas", "numpy", "matplotlib"])

# Start Streamlit
print("Starting server on port 8501...")
proc = subprocess.Popen([
    "streamlit", "run", r"C:\Users\pavan\Documents\Github P1\predictive-maintenace-system\app\dashboard.py",
    "--server.port", "8501",
    "--server.headless", "true",
    "--browser.serverAddress", "localhost"
])

# Wait and open browser
time.sleep(3)
print("Opening browser...")
webbrowser.open("http://localhost:8501")

print("✅ Dashboard should be open in your browser!")
print("Press Ctrl+C to stop")
proc.wait() 